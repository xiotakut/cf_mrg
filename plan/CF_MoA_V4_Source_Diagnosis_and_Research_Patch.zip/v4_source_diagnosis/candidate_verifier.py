"""Research prototype: verify existing F candidates instead of fresh-answer overwrite.

No new candidate generation, no training, no gold access, no model loading here.
The caller supplies the repository's EXISTING ModelSession.score method:
    result = verify_saved_sample(sample, session.score)

Run initially as a separate experimental arm. This file has synthetic tests,
NOT an accuracy guarantee or a completed evaluation on the private 95 cases.
P(True) is an uncalibrated ranking signal, NOT a clinical probability.
"""
from __future__ import annotations
import copy
import json
import math
from typing import Any, Callable
from cached_f_experiments import candidate_records, unwrap, VOTE


def true_probability(logps: dict[str, float], true_code: str) -> float:
    if set(logps) != {'A', 'B'} or not all(math.isfinite(v) for v in logps.values()):
        raise ValueError('Expected two finite A/B log probabilities')
    peak = max(logps.values())
    z = sum(math.exp(v - peak) for v in logps.values())
    return math.exp(logps[true_code] - peak) / z


def verifier_messages(packet: dict[str, Any], candidates: list[dict[str, Any]],
                      target_key: str, true_code: str,
                      include_rationales: bool = True) -> list[dict[str, str]]:
    # Only original visible context and native semantics go into this request.
    # Exclude export IDs, family/source IDs, correctness flags and offline gold.
    context = copy.deepcopy(packet['original_context'])
    if isinstance(context, str):
        context = [{'role': 'user', 'content': context}]
    item = packet['native_input']
    brief = []
    for c in candidates:
        entry = {'native_key': c['key']}
        if include_rationales:
            entry['fallible_saved_reasoning'] = c['rationale']
        brief.append(entry)
    if true_code not in ('A', 'B'):
        raise ValueError('Unknown verification mapping')
    false_code = 'B' if true_code == 'A' else 'A'
    task = {
        'current_question': item.get('question', packet.get('question', '')),
        'native_options': item.get('options', {}),
        'candidate_to_verify': target_key,
        'already_generated_candidates': brief,
    }
    instruction = (
        'Perform candidate verification, not a fresh solution and not a vote. '
        'For this check only, determine whether candidate_to_verify is the correct '
        'answer to the exact CURRENT question under its original task semantics. '
        'Correct means the requested best choice/relation, not merely a generally '
        'true medical statement. Preserve the given subject, age versus symptom '
        'duration, negation, quantities, intervention, outcome and time. '
        'If the original task uses provided or counterfactual evidence, judge '
        'faithfully under that specified contract rather than silently replacing it '
        'with a different real-world question. Existing candidate explanations are '
        'fallible hypotheses, never new patient observations or verified evidence. '
        'Evaluate against the full original input above; frequency is not evidence. '
        'Use only this verification code mapping:\n'
        f'{true_code} = the target candidate is correct for the current question\n'
        f'{false_code} = the target candidate is not correct for the current question\n'
        'Return only the mapped A/B value in answer_choice. Do not return a native '
        'option key or a long explanation.\n\n' + json.dumps(task, ensure_ascii=False)
    )
    return [*context, {'role': 'user', 'content': instruction}]


def verify_saved_sample(sample: dict[str, Any], score: Callable[..., dict[str, float]],
                        include_rationales: bool = True) -> dict[str, Any]:
    f = unwrap(sample['f_proposal'])['proposal']
    base = f['native_proposal']
    trace = f['trace']
    # Do not treat four mapped NLI distributions as four generated candidates.
    # This prototype deliberately keeps the existing NLI expert untouched.
    if trace['route'] != VOTE:
        return {'native_answer': copy.deepcopy(base), 'status': 'retained_nonvote_path',
                'logical_score_calls': 0, 'scores': {}}
    candidates = candidate_records(sample)
    if len(candidates) < 2:
        return {'native_answer': copy.deepcopy(base), 'status': 'retained_no_competition',
                'logical_score_calls': 0, 'scores': {}}
    packet = unwrap(sample['input_packet'])
    records = []
    errors = []
    for c in candidates:
        vals = []
        for mapping_i, true_code in enumerate(('A', 'B')):
            messages = verifier_messages(packet, candidates, c['key'], true_code,
                                         include_rationales=include_rationales)
            try:
                lp = score(messages=messages, codes=['A', 'B'], seed=42,
                           stage=f'candidate_verify:{c["key"]}:{mapping_i}')
                p = true_probability(lp, true_code)
                records.append({'key': c['key'], 'mapping': mapping_i,
                                'true_code': true_code, 'logps': lp, 'p_true': p})
                vals.append(p)
            except Exception as exc:
                errors.append({'key': c['key'], 'mapping': mapping_i, 'error': repr(exc)})
        c['verification_score'] = sum(vals) / 2 if len(vals) == 2 else None
    if errors:
        # Technical failure is reported and remains in the denominator. It does
        # not stop other samples. The surrounding runner may retry a failed
        # service call once with exactly the same request, never based on gold.
        return {'native_answer': copy.deepcopy(base), 'status': 'technical_failure',
                'errors': errors, 'records': records,
                'logical_score_calls': 2 * len(candidates)}
    scores = {c['key']: c['verification_score'] for c in candidates}
    best = max(scores.values())
    tied = [c['key'] for c in candidates if scores[c['key']] == best]
    key = base['answer_choice'] if base['answer_choice'] in tied else tied[0]
    winner = next(c for c in candidates if c['key'] == key)
    # Return a COMPLETE original response of the selected candidate. Do not
    # graft a changed key onto a different sample's errors/auxiliary evidence.
    native = base if key == base['answer_choice'] else winner['native_response']
    return {'native_answer': copy.deepcopy(native), 'status': 'verified_candidate_selection',
            'selected_key': key, 'scores': scores, 'records': records,
            'selected_original_response_index': winner['original_response_index'],
            'logical_score_calls': 2 * len(candidates),
            'new_answer_generation_calls': 0,
            'score_interpretation': 'uncalibrated selection score, not clinical probability'}
