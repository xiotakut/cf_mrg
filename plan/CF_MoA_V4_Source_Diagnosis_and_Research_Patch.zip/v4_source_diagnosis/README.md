# CF-MoA V4 源码诊断后的最小研究补丁

日期：2026-09-24。

本包不是新的已验证有效方法。它包含依据公开实际调用链提出的具体修改指令，以及可直接接入现有环境的小型研究代码。没有访问未公开的95例完整正文，没有在这些病例上运行新模型，也没有声称提升。

| 文件 | 用途 |
|---|---|
| `CF_MoA_V4_Source_Diagnosis_and_Coding_Instructions.md` | 原因、证据、唯一新增实验、coding-agent 指令 |
| `cached_f_experiments.py` | 直接读取既有私有导出包，运行固定的零新推理重聚合实验；NLI不当普通票 |
| `candidate_verifier.py` | 现有候选逐项验证、两编码映射取分、选回完整原生响应；复用 `ModelSession.score` |
| `test_research_kernels.py` | 9项合成测试，包括“唯一领先者追加一票不能被超过”的枚举检验 |
| `public_numbers_recomputed.json` | 根据公开分层表复算的NLI/非NLI净变化；非新模型结果 |

## 运行离线固定策略

```bash
python cached_f_experiments.py \
  --bundle /path/to/extracted/cf_moa_v4_trigger_diagnosis_20260924_private \
  --public-csv /path/to/repo/benchmarks/2026-09-24_cf_moa_v4_diagnosis/data/per_trigger_seed.csv \
  --out /path/to/new/cached_f_policy_results
```

它不重新导出，不导入模型，不补造早停后未运行的样本。生成策略输出后才使用离线标签评分。该附带评分只用于触发集合的键正确率，不能替代原项目的原生单元和辅助字段评测。

## 接入候选验证实验

在现有 runner 创建好与原骨干匹配的 `ModelSession` 后：

```python
from candidate_verifier import verify_saved_sample
result = verify_saved_sample(private_export_sample, session.score)
# 无旧解释控制：
control = verify_saved_sample(private_export_sample, session.score,
                              include_rationales=False)
```

同一个 `session` 的预算需按两臂实际调用合计设置；通常应分别建立 session 或 checkpoint 以便计费。每个独立候选两次A/B取分；最终返回已有完整响应，不再生成一份长答案。

本地已运行合成测试；服务器真实数据与真实骨干尚需由 coding agent 执行。合成测试通过只说明函数和接口逻辑，不说明医学准确率提高。

```bash
python -m unittest -v test_research_kernels.py
```
