import copy
import itertools
import json
import math
import unittest
from cached_f_experiments import vote_winner, experiment_sample, candidate_records, VOTE, NLI
from candidate_verifier import verify_saved_sample, verifier_messages, true_probability


def sample(votes=('A','B','A','A'), news=('B','B','B')):
    natives = [dict(answer_choice=k, step_by_step_thinking='fallible reasoning '+k,
                    errors=[{'sample_marker': i}]) for i,k in enumerate(votes)]
    b = vote_winner(votes)
    base = next(n for n in natives if n['answer_choice'] == b)
    f = {'native_proposal': base, 'trace': {'route': VOTE, 'predictions':list(votes),
                    'responses':[json.dumps(n) for n in natives]}}
    return {'sample_id':'synthetic:0','panel':'synthetic','method':'M4','request_id':'0',
      'input_packet':{'record':{'original_context':[{'role':'user','content':'Original allowed input'}],
         'native_input':{'question':'Choose the requested answer', 'answer_format':'single',
                        'options':{'A':'option a','B':'option b','C':'option c'}}}},
      'f_proposal':{'record':{'proposal':f}},
      'reanswers':{str(seed):{'output':{'record':{'result':{'native_answer':dict(base,answer_choice=k)}}}}
                   for seed,k in zip((42,43,44),news)}}

class Kernels(unittest.TestCase):
    def test_unique_leader_one_vote_never_overrules_with_incumbent_tie(self):
        for n in range(1,6):
            for votes in itertools.product('ABC',repeat=n):
                counts={k:votes.count(k) for k in 'ABC'}
                leaders=[k for k,v in counts.items() if v==max(counts.values())]
                if len(leaders)==1:
                    for extra in 'ABCD':
                        self.assertEqual(vote_winner([*votes,extra],leaders[0]),leaders[0])

    def test_tie_can_change(self):
        self.assertEqual(vote_winner(['A','B','A','B','C','B'],'A'),'B')

    def test_cached_replacement_vs_added_vote(self):
        s=sample()
        out=experiment_sample(s)
        rows={r['arm']:r for r in out['rows']}
        self.assertEqual(rows['replace_42']['selected_key'],'B')
        self.assertEqual(rows['append_one_42']['selected_key'],'A')
        self.assertEqual(rows['pool_old_plus_three']['selected_key'],'B')
        self.assertEqual(rows['pool_old_plus_three']['prospective_extra_generation_calls'],3)

    def test_all_existing_options_kept_no_gold_top2(self):
        s=sample(('A','B','C','A','B'))
        self.assertEqual([c['key'] for c in candidate_records(s)],['A','B','C'])

    def test_probability_mapping(self):
        self.assertAlmostEqual(true_probability({'A':-1000.,'B':-1001.},'A'),1/(1+math.exp(-1)))
        self.assertAlmostEqual(true_probability({'A':-1001.,'B':-1000.},'B'),1/(1+math.exp(-1)))

    def test_choose_score_not_majority_and_return_whole_response(self):
        s=sample(); original=copy.deepcopy(s)
        calls=[]
        def score(**kwargs):
            calls.append(kwargs)
            stage=kwargs['stage']; key=stage.split(':')[1]; reverse=stage.endswith(':1')
            good=key=='B'; tc='B' if reverse else 'A'; fc='A' if reverse else 'B'
            return {tc: -0.1 if good else -2., fc:-2. if good else -0.1}
        out=verify_saved_sample(s,score)
        self.assertEqual(out['selected_key'],'B')
        self.assertEqual(out['native_answer']['errors'],[{'sample_marker':1}])
        self.assertEqual(out['logical_score_calls'],4)
        self.assertEqual(s,original)
        self.assertNotIn('sample_id',json.dumps(calls))

    def test_nli_untouched(self):
        s=sample();s['f_proposal']['record']['proposal']['trace']['route']=NLI
        out=verify_saved_sample(s,lambda **kw: (_ for _ in ()).throw(AssertionError()))
        self.assertEqual(out['logical_score_calls'],0)

    def test_no_rationale_control(self):
        s=sample(); p=s['input_packet']['record']; cs=candidate_records(s)
        msg=verifier_messages(p,cs,'A','A',include_rationales=False)
        self.assertNotIn('fallible reasoning A',msg[-1]['content'])

    def test_technical_failure_keeps_trace_not_silent_success(self):
        s=sample()
        def fail(**kwargs):raise RuntimeError('service failure')
        out=verify_saved_sample(s,fail)
        self.assertEqual(out['status'],'technical_failure')
        self.assertEqual(len(out['errors']),4)

if __name__=='__main__':unittest.main()
