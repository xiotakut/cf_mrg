#!/usr/bin/env python3
"""Small, offline experiments on the EXISTING 95-sample private export.

No model calls, no generation, no head imports, no invented votes. Selection
functions do not access gold. Optional scoring joins the existing public table
only AFTER every candidate result has been written. This is a new offline
experiment, not a claimed completed rerun on the user's private data.

Example:
  python cached_f_experiments.py \
    --bundle /path/to/extracted_private_zip \
    --public-csv /repo/.../data/per_trigger_seed.csv \
    --out /path/to/new/cached_selection_results

The bundle structure follows the published analysis_code/export_samples.py.
"""
from __future__ import annotations
import argparse
import copy
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

NLI = 'full_nli_equal_paths_native_completion'
VOTE = 'full_native_key_maj5_absolute_majority_stop'
SEEDS = ('42', '43', '44')


def vote_winner(votes: Iterable[str | None], incumbent: str | None = None) -> str:
    """Unweighted votes; incumbent wins a tied maximum, otherwise first seen.

    None is not a vote. Passing incumbent=None reproduces F's original
    first-observed-leader tie rule (for an already parsed vote sequence).
    """
    valid = [x for x in votes if isinstance(x, str)]
    if not valid:
        raise ValueError('No valid, actually observed votes')
    counts = Counter(valid)
    leaders = {x for x, n in counts.items() if n == max(counts.values())}
    if incumbent in leaders:
        return str(incumbent)
    return next(x for x in valid if x in leaders)


def unwrap(x: dict[str, Any]) -> dict[str, Any]:
    return x['record']


def candidate_records(sample: dict[str, Any]) -> list[dict[str, Any]]:
    """Original non-NLI F candidates only; one full earliest response per key.

    Select earliest response deterministically, never using gold, score, length,
    or a preference inferred from the offline review. Do not fill missing
    reasoning by generation. Additional same-key responses remain in the source.
    """
    f = unwrap(sample['f_proposal'])['proposal']
    trace = f['trace']
    if trace['route'] != VOTE:
        return []
    packet = unwrap(sample['input_packet'])
    item = packet['native_input']
    keys = list(item.get('options') or {})
    if item['answer_format'] == 'relation':
        keys = ['higher', 'lower', 'no difference', 'uncertainty']
    by_key: dict[str, dict[str, Any]] = {}
    votes = trace['predictions']
    for i, (key, raw) in enumerate(zip(votes, trace['responses'])):
        if key not in keys or key in by_key:
            continue
        native = json.loads(raw)
        if native.get('answer_choice') != key:
            raise ValueError(f'Saved response/key mismatch at original index {i}')
        by_key[key] = dict(key=key, native_response=native,
                           original_response_index=i,
                           rationale=native.get('step_by_step_thinking', ''))
    return [by_key[k] for k in keys if k in by_key]


def experiment_sample(sample: dict[str, Any]) -> dict[str, Any]:
    f = unwrap(sample['f_proposal'])['proposal']
    trace = f['trace']
    base = f['native_proposal']
    b = base['answer_choice']
    old_votes = trace.get('predictions', [])
    news = {seed: unwrap(sample['reanswers'][seed]['output'])['result']['native_answer']
            for seed in SEEDS}
    rows = []

    def add(arm: str, key: str, native: dict[str, Any], seeds: tuple[str, ...] = ()) -> None:
        # New computation costs zero LLM calls now, but using 3 saved answers in
        # a policy would still require THREE extra calls at deployment.
        rows.append(dict(arm=arm, selected_key=key, native_response=copy.deepcopy(native),
                         supplementary_seeds_used=list(seeds),
                         prospective_extra_generation_calls=len(seeds),
                         new_model_calls_in_this_analysis=0))

    add('F', b, base)
    for seed in SEEDS:
        add('replace_' + seed, news[seed]['answer_choice'], news[seed], (seed,))
        native = base if trace['route'] == NLI else news[seed]
        add('replace_non_nli_' + seed, native['answer_choice'], native,
            () if trace['route'] == NLI else (seed,))

    if trace['route'] == NLI:
        # Top-1s from mapped probabilities are NOT four independent full answers.
        for seed in SEEDS:
            add('append_one_' + seed, b, base)
        add('pool_old_plus_three', b, base)
        return dict(sample_id=sample['sample_id'], panel=sample['panel'],
                    method=sample['method'], request_id=sample['request_id'],
                    path=trace['route'], baseline_key=b, rows=rows,
                    single_added_vote_can_change=None,
                    note='NLI retained unchanged; no conversion of probabilities into votes.')

    if trace['route'] != VOTE:
        raise ValueError('Unexpected F path: ' + str(trace['route']))
    if vote_winner(old_votes) != b:
        raise ValueError('Saved F output does not reproduce first-leader voting')
    representatives = {c['key']: c['native_response'] for c in candidate_records(sample)}
    representatives[b] = base

    def materialize(key: str, used: tuple[str, ...]) -> dict[str, Any]:
        if key in representatives:
            return representatives[key]
        return next(news[seed] for seed in used if news[seed]['answer_choice'] == key)

    for seed in SEEDS:
        key = vote_winner([*old_votes, news[seed]['answer_choice']], incumbent=b)
        add('append_one_' + seed, key, materialize(key, (seed,)), (seed,))
    key = vote_winner([*old_votes, *(news[s]['answer_choice'] for s in SEEDS)], incumbent=b)
    add('pool_old_plus_three', key, materialize(key, SEEDS), SEEDS)
    legal = list(unwrap(sample['input_packet'])['native_input'].get('options') or {})
    if not legal:
        legal = ['higher', 'lower', 'no difference', 'uncertainty']
    counts = Counter(x for x in old_votes if isinstance(x, str))
    leaders = [k for k, v in counts.items() if v == max(counts.values())]
    return dict(sample_id=sample['sample_id'], panel=sample['panel'],
                method=sample['method'], request_id=sample['request_id'],
                path=trace['route'], baseline_key=b, rows=rows,
                actual_old_vote_counts=dict(counts), original_leaders=leaders,
                single_added_vote_can_change=any(
                    vote_winner([*old_votes, k], incumbent=b) != b for k in legal),
                note='Actual observations only; stopped F draws are not invented.')


def manifest_path(bundle: Path) -> Path:
    if (bundle / 'sample_manifest.json').is_file():
        return bundle / 'sample_manifest.json'
    candidates = list(bundle.rglob('sample_manifest.json'))
    if len(candidates) != 1:
        raise FileNotFoundError('Point --bundle at the existing private export containing sample_manifest.json')
    return candidates[0]


def evaluate_written_predictions(result_file: Path, public_csv: Path, out: Path) -> None:
    # This entire function is OFFLINE evaluation, after selection outputs exist.
    labels: dict[tuple[str, str, str], tuple[str, ...]] = {}
    with public_csv.open(encoding='utf-8', newline='') as f:
        for row in csv.DictReader(f):
            ident = (row['panel'], row['method'], row['request_id'])
            gs = tuple(json.loads(row['gold_keys']))
            if ident in labels and labels[ident] != gs:
                raise ValueError('Gold metadata mismatch across saved seeds')
            labels[ident] = gs
    groups = defaultdict(lambda: Counter())
    for line in result_file.read_text(encoding='utf-8').splitlines():
        case = json.loads(line)
        ident = (case['panel'], case['method'], case['request_id'])
        golds = labels[ident]
        b_ok = all(case['baseline_key'] == g for g in golds)
        for row in case['rows']:
            ok = all(row['selected_key'] == g for g in golds)
            for path_group in ('ALL', case['path']):
                g = groups[(case['panel'], case['method'], path_group, row['arm'])]
                g.update(n=1, baseline_correct=int(b_ok), correct=int(ok),
                         repair=int(ok and not b_ok), harm=int(b_ok and not ok),
                         changed=int(row['selected_key'] != case['baseline_key']),
                         prospective_extra_generation_calls=row['prospective_extra_generation_calls'])
    report = []
    for (panel, method, route, arm), g in sorted(groups.items()):
        report.append(dict(panel=panel, method=method, route=route, arm=arm, **g,
                           net=g['repair'] - g['harm']))
    (out / 'offline_key_metrics.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    # This is trigger-level exact key evaluation, not a replacement for the
    # repository's complete native-unit/auxiliary-field scoring.


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--bundle', type=Path, required=True)
    ap.add_argument('--public-csv', type=Path)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    mp = manifest_path(args.bundle)
    manifest = json.loads(mp.read_text(encoding='utf-8'))
    args.out.mkdir(parents=True, exist_ok=True)
    result_file = args.out / 'cached_policy_predictions.jsonl'
    failures = []
    changes = Counter()
    with result_file.open('w', encoding='utf-8') as sink:
        for entry in manifest['samples']:
            try:
                sample = json.loads((mp.parent / entry['sample_path']).read_text(encoding='utf-8'))
                result = experiment_sample(sample)
                sink.write(json.dumps(result, ensure_ascii=False) + '\n')
                flag = result['single_added_vote_can_change']
                changes['not_applicable_nli' if flag is None else ('can_change' if flag else 'cannot_change')] += 1
            except Exception as exc:
                # Record rather than silently drop or abort every other case.
                failures.append(dict(sample_id=entry.get('sample_id'), error=repr(exc)))
    (args.out / 'failures.json').write_text(json.dumps(failures, ensure_ascii=False, indent=2), encoding='utf-8')
    (args.out / 'readout_arithmetic.json').write_text(json.dumps(dict(changes), indent=2), encoding='utf-8')
    if args.public_csv:
        evaluate_written_predictions(result_file, args.public_csv, args.out)
    print(json.dumps(dict(completed=sum(changes.values()), failures=len(failures),
                          new_model_calls=0, **changes), ensure_ascii=False, indent=2))
    if failures:
        print('Failed cases are listed; do not claim complete-panel quality until they are resolved.')


if __name__ == '__main__':
    main()
