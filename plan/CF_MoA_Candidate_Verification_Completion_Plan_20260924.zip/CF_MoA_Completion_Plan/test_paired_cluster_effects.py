import unittest
from paired_cluster_effects import summarize

def row(i, f, b, c, w=1):
    return dict(atom_id=str(i),family_id=str(f),baseline_score=b,candidate_score=c,weight=w)

class PairedBootstrapTests(unittest.TestCase):
    def test_identical(self):
        r=summarize([row(0,'a',1,1),row(1,'b',0,0)],200)
        self.assertEqual(r['point_delta'],0)
        self.assertEqual(r['paired_cluster_ci95'],[0,0])
    def test_constant_gain(self):
        r=summarize([row(0,'a',0,.25),row(1,'b',.5,.75)],200)
        self.assertEqual(r['point_delta'],.25)
        self.assertEqual(r['paired_cluster_ci95'],[.25,.25])
    def test_original_unit_weighting(self):
        r=summarize([row(0,'a',0,1),row(1,'a',0,1),row(2,'b',1,0)],200)
        self.assertAlmostEqual(r['point_delta'],1/3)
        self.assertEqual(r['families'],2)
    def test_natural_M5_documented_delta(self):
        rows=[row(0,'a',1,0),row(1,'b',.2,.6),row(2,'c',0,.4)]
        rows += [row(i,str(i),.5,.5) for i in range(3,18)]
        r=summarize(rows,200)
        self.assertAlmostEqual(r['point_delta_percentage_points'],-1.1111111111111112)
    def test_reproducible(self):
        data=[row(0,'a',1,0),row(1,'b',0,1),row(2,'c',0,.5)]
        self.assertEqual(summarize(data,200,1),summarize(data,200,1))
    def test_invalid_not_silently_dropped(self):
        with self.assertRaises(ValueError): summarize([row(0,'a',None,0)],10)
    def test_single_family_not_invent_CI(self):
        self.assertIsNone(summarize([row(0,'a',0,1)])['paired_cluster_ci95'])
    def test_duplicate_atom(self):
        with self.assertRaises(ValueError): summarize([row(0,'a',0,1),row(0,'a',0,1)],10)
    def test_explicit_weights(self):
        r=summarize([row(0,'a',0,1,2),row(1,'b',1,0,1)],200)
        self.assertAlmostEqual(r['point_delta'],1/3)
    def test_empty(self):
        self.assertEqual(summarize([])['status'],'empty_stratum')

if __name__=='__main__': unittest.main()
