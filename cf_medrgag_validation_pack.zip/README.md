# CF-WM-MedRGAG Validation Pack

A reproducible evaluation plan for testing whether a world-model-style layer adds **counterfactual state/action reasoning** beyond MedRGAG's retrieval–generation–selection pipeline.

## Recommended benchmark stack

1. **MedPIC-Bench** — primary static-text benchmark for patient-specific rule activation/deactivation and action applicability.
2. **CLIR-Bench** — strongest public benchmark for temporal state, intervention response, forecasting, decision making, and counterfactual evidence edits.
3. **MedEinst** — cross-domain test of diagnosis revision after minimal changes to discriminative patient evidence.
4. **MedCounterFact** — RAG/GAG-specific stress test for evidence–parametric-knowledge conflicts and unsafe/implausible counterfactual evidence.
5. **ReMedQA + CPV/MedEqualQA** — invariant/format controls; not evidence for a world-model claim by themselves.
6. **CLADDER** — optional formal causal sanity check for the standalone counterfactual module.
7. **CP-Env** — optional high-cost dynamic clinical-pathway validation after static/temporal pilots succeed.

## Main claim boundary

The public suite can test four distinct capabilities:

- conditional rule applicability;
- patient-state revision;
- intervention/temporal response reasoning;
- evidence-conflict handling.

No single public dataset proves a general clinical world model. Use the term **guideline-grounded textual clinical world-model layer** only if the full model beats decomposition, extra-retrieval, and equal-compute baselines and passes causal-edit/shuffle tests.

## Package contents

- `PROJECT_PLAN.md`: complete Chinese research plan.
- `AGENTS.md`: coding-agent constraints and project invariants.
- `datasets/DATASET_MATRIX.md`: selection rationale and adaptation rules.
- `prompts/`: executable prompt templates.
- `configs/`: dataset, experiment, and go/no-go manifests.
- `schemas/unified_item.schema.json`: common record format.
- `scripts/validate_manifest.py`: basic leakage/schema checks.
- `references/SOURCES.md`: official paper/dataset locations.
