# R1–R5分类规则与修订

最新状态：2026-09-14（Asia/Shanghai，文档迁移时）。本文件是分类定义、判定边界和实例的主记录。当前v5保留原labels语义，以evaluation_labels表示评测成员；规则、数据资格和模型评分分别记录。

[工作区总入口](/home/data3/txy/docs/README.md) · [记录归属与迁移证据](/home/data3/txy/docs/workspace.md#documentation-migration-20260914)

本文是该方向的长期主记录。下文按来源章节合入实际正文，保留历史配置、成功/失败尝试、结果与证据。历史段落中的“当前”“继续在原文件更新”和运行中状态均以其原记录日期为准；今后在本文件续写。

## 内容导航

- [R1–R5 classification guide and completed expansion (2026-09-10)](#record-0020)
- [6. 从计划到跨对话分类指南：文档本身改了什么](#record-0242)
- [R1_R5_CLASSIFICATION_GUIDE.md](#record-0253)

<a id="record-0020"></a>

## R1–R5 classification guide and completed expansion (2026-09-10)

来源：[MEDRGAG_WORKSPACE_GUIDE.md](/home/data3/txy/MEDRGAG_WORKSPACE_GUIDE.md)，原文第846行起。命令以原文指定工作目录为准；相对文件引用原属 `/home/data3/txy`。

##### R1–R5 classification guide and completed expansion (2026-09-10)

For a new local conversation continuing classification, read
[R1_R5_CLASSIFICATION_GUIDE.md](/home/data3/txy/docs/data/classification.md#record-0253) first. It contains
the user's original five definitions, concrete decision rules, reviewed positive
examples and corrected counterexamples with original IDs, target-level annotation
and eligibility handling, and the local source files. The matching
[GitHub guide](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-10_r1_r5_full_coverage_plan/README.md)
is the published copy.

Keep v3 and all completed results. The completed classification covers eligible content
in the 15 acquired sources, including 24,436 candidates omitted by the old sampling
and renewed eligibility review of 18,238 already-classified R5 candidates deferred
by the old scope limit. The old 2,500 sampling rule and R5 size/source cap are
historical; they do not govern the next version. Evidence-based exclusions still
apply. The classification and qualification work is complete; read `$CF_CLASSIFIED_FULL/DELIVERY.md` and the latest-delivery section above. New model evaluation has not started.

<a id="record-0242"></a>

## 6. 从计划到跨对话分类指南：文档本身改了什么

来源：[R1_R5_V3_BASELINES_WORK_RECORD.md](/home/data3/txy/R1_R5_V3_BASELINES_WORK_RECORD.md)，原文第122行起。命令以原文指定工作目录为准；相对文件引用原属 `/home/data3/txy`。

#### 6. 从计划到跨对话分类指南：文档本身改了什么

第一次发布的补分类计划以范围、阶段、交付和执行建议为主。用户随后明确其用途是本地其他对话的分类指南，要求核心部分是之前的具体规则和示例，并删除推荐运行配置。实际调整如下。

| 修改前 | 修改后 | 目的 / 检查 |
|---|---|---|
| 主要按执行步骤展开，五类定义只有简表 | 五类逐节给出定义、成立条件、正例、反例、不能推出的结论 | 让接手者可以直接判断新题，而不只是知道待办数量 |
| 边界分散在早期对话和审核表中 | 找回用户原方案，整理删除不等于否定、支持不等于确诊、R3 双候选、R4 非复述、R5 非答案相同等边界 | 保持原标准，防止将名称当成关键词分类器 |
| 抽象示例与实际数据容易混淆 | 区分解释定义的教学示例和带原始 ID 的已审实例 | 教学示例不进入 benchmark；13 个具体实例的当前标签与修正表核对一致 |
| 父标签可能掩盖子目标状态 | 补上具体判断、父标签并集、比较轴、语义标签与展示类别的区别 | 避免将一个目标的 R5 复制到其他任务 |
| 推荐运行配置写进计划 | 从现行分类指南全部移除 | 属于文档内容调整，没有据此切换实验骨干或重跑实验 |
| 文件主要放在 GitHub 日期目录 | 建立 `/home/data3/txy/R1_R5_CLASSIFICATION_GUIDE.md`，在共享 `AGENTS.md` 和工作区指南加入口；GitHub 保留同步副本 | 其他本地对话能直接找到规则、实例和原始数据位置 |
| 补分类尚未执行的初始状态 | 后续交付在指南中追加 v4 完成与 v5 选择入口 | 执行要求和实际完成日期分别保留 |

当前指南主体是分类规范，本文则记录实际做过的工作和变化原因。后续推荐、经验或临时讨论不会自动成为分类规范；规范发生实质变化时，应明确生效版本及受影响记录。

<a id="record-0253"></a>

## R1_R5_CLASSIFICATION_GUIDE.md

来源：[R1_R5_CLASSIFICATION_GUIDE.md](/home/data3/txy/R1_R5_CLASSIFICATION_GUIDE.md)，原文第1行起。命令以原文指定工作目录为准；相对文件引用原属 `/home/data3/txy`。

### 医学 R1–R5 分类指南：原有规则、示例与后续补分类

2026-09-13 实施记录补充：[v3 基线与分类指南的工作及调整记录](/home/data3/txy/docs/archive/r1_r5_early_evaluation.md#record-0233)保存 M2/M3 实际调整、方法身份、指南修订和论文表述；[GitHub 副本](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-13_r1_r5_v3_methods_record/README.md)。其中也链接已完成的后续 v5 M0/M2/M3/M4/M5 结果；下文 09-10 的“尚未运行”描述对应构建阶段。

2026-09-13 文档补充：论文方法、具体调整和版本沿革统一见[工作过程与调整记录](/home/data3/txy/docs/data/construction.md#record-0351)（[GitHub](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-10_r1_r5_process_history/README.md)）。本指南下文保留原日期的规则与交付状态；后续运行是否完成以运行包最终报告为准。

更新：2026-09-10。用途：**供本地其他对话接手分类时直接阅读和执行。** 本地入口为 `/home/data3/txy/R1_R5_CLASSIFICATION_GUIDE.md`；本页为 GitHub 同步副本。

本指南依据用户 09-08 会话中提供的 09-07 分类方案、[原分类说明](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/分类与抽样说明.md)、[已审具体判断](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/data/analysis_judgments.csv.gz)及[后续纠错记录](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/corrections/README.md)整理。正文先说明怎样判断 R1–R5，再说明补分类范围和文件位置。“定义示例”来自原方案或其抽象表达，用来解释规则，不能加入 benchmark；“已审实例”带原始 ID，反映留存的具体裁决。

当前 v3 的 3,105 个单元及全部已有结果保留。后续扩充另建版本，取消因数量而抽样、限制 R5 来源或砍掉 R5 的做法；有明确内容、分类或评分问题的项目仍按证据处置。本轮补分类与资格整理现已完成，详见下方交付入口；新版评测尚未执行。

#### 后续评测选择：v5（2026-09-10）

完整v4保持不变。用户在比较整来源排除、比例抽样和五轮理由/反驳后，明确批准八个来源各随机抽450个R5比较单元，共3,600个，并另存为v5。R1–R4全部合格目标保留；v5共6,104个去重单元、13,000个具体判断。

这是分类完成后的评测预算选择，不是恢复历史分类前2,500抽样，也不是删除完整v4。原标签在 `labels` 中保留；本轮评测只读取 `evaluation_labels`。抽样种子一次生成，完整候选清单和选中ID可独立重放；未按原题/人口属性配额重抽。

[GitHub v5说明与探索记录](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-10_r1_r5_v5/README.md)。本地入口：`/home/data3/txy/Documents/Codex/2026-09-09/agent-md-medrgag-workspace-guide-md/benchmark_r1_r5_v5_20260910/README.md`；探索全过程见同目录 `EXPLORATION_HISTORY.md`。v3评测结果保留，v4完整分类仍为母集；v5运行接口尚未验证。

#### 本轮完成状态与新文件入口（2026-09-10）

24,436 个抽样遗漏单元全部处置，其中 18,023 个可测；18,238 个旧 R5 单元复用原标注，其中既有目标恢复资格 16,972 个单元。另补判已有单元上的 3,615 个 RESOURCE 目标，其中 3,529 个可测，不能与单元数相加。全母库 55,991 个单元均有去向，最终 38,123 个单元至少有一个合格目标，共 77,781 个合格具体判断。

10 个新查明的实际无变化控制采用独立资格修正文件；旧标签、理由、证据与原始记录保留。需要缺失多模态输入的目标禁用，未再次随机抽样。v3 及既有结果保留。新版尚未生成模型输入/评分映射运行包，也未完成新的 M0–M3 评测。

- [GitHub 完成说明、来源统计与图表](https://github.com/xiotakut/cf_mrg/tree/main/benchmarks/2026-09-10_r1_r5_full_classification/README.md)
- 本地交付说明：`/home/data3/txy/Documents/Codex/2026-09-09/agent-md-medrgag-workspace-guide-md/benchmark_r1_r5_v4_20260910/DELIVERY.md`
- 最终逐目标标注与资格：`/home/data3/txy/Documents/Codex/2026-09-09/agent-md-medrgag-workspace-guide-md/benchmark_r1_r5_v4_20260910/exports/all_reviewed_target_annotations.jsonl.gz`
- 全母库去向：`/home/data3/txy/Documents/Codex/2026-09-09/agent-md-medrgag-workspace-guide-md/benchmark_r1_r5_v4_20260910/exports/archive_unit_coverage.csv`
- 本地来源/排除说明、图表和覆盖检查分别见同目录 `source_scope_inventory.md`、`figures/README.md`、`completion_audit.json`。

第 11 节保留本轮执行范围与要求，后续对话应读取上述完成文件，按已有 ID 复用结果。

#### 1. 原来确定的五类定义

| 标签 | 原定义 | 原方案中的定义示例 |
|---|---|---|
| **R1 新增支持** | 改变后的条件，为一个具体判断增加了原先没有的支持。 | 新出现的检查结果支持某诊断；患者新满足某项用药规则的条件。 |
| **R2 撤销支持** | 原先支撑某个判断的条件消失了，或被新的事实反驳了。 | 原先触发禁忌的条件被明确取消，不能继续沿用这条禁忌理由。 |
| **R3 重新比较** | 变化影响了多个候选判断的相对依据，需要重新比较诊断或处理方案。 | 原证据更支持诊断 A，新证据更支持诊断 B，需要重新比较两者。 |
| **R4 推导后果** | 前提改变后，根据有依据的医学关系，推断未直接给出的后续结果。 | 题目明确给出某处理影响某指标；改变处理后，推断指标或相关风险如何变化。 |
| **R5 保持判断** | 对当前具体问题，这项变化不应改变需要保持的正确判断或内容。 | 改变与该题无关的身份信息，诊断应保持；更新一条医学知识，不应破坏其他无关知识。 |

R1、R2 看**一个判断的依据**；R3 看**候选之间的相对依据**；R4 看**改变前提后的后续结果**；R5 看**具体什么应不受影响**。分类对象是一道题、官方对照组或其中的具体判断，不是整份 benchmark。

原方案要求保留的三处边界：

1. **依据变化不等于最终答案必须变化。** 新支持不等于确诊；撤销某条禁忌理由不等于现在就应该选择该药或行动；原文没写不等于明确没有。
2. **R1–R3 可以共现，但各自需要依据。** 答案从 A 变成 B，不能自动产生三个标签。
3. **R5 由任务与内容决定。** 模型两次给出同一答案，或原 gold 恰好相同，不能单独证明正确判断应保持。

#### 2. 每条记录先做什么

收集范围沿用医学专用方案：综合 benchmark 只取明确的医学 CF 子任务及必要参照，不把普通医学问答、通用常识、故事或纯认知提示干扰整包纳入。无实际变化以及纯风格/格式对照单列，不用来补 CF 数量。

先读原题、变体、必要参照、原生任务要求和具体目标，再标注。无需给每题建立复杂因果图，但必须明确以下五项：

| 项目 | 必须写清楚的内容 | 原方案的抽象示例 |
|---|---|---|
| `change` 改了什么 | 哪个对象的哪个条件在何种比较中改变 | 条件 C 由明确存在改为明确不存在 |
| `target` 判断对象 | 一个可核查的判断；多个目标分开 | 是否因为 C 而禁止行动 A |
| `labels` 功能标签 | 该变化对这个目标的功能 | R2 撤销支持 |
| `rationale` / `evidence` 判定依据 | 原规则、实际变化及连接关系；给原文或文件定位 | 原规则将限制与 C 绑定，变体明确取消 C |
| `cannot_infer` 不能进一步推出什么 | 不被现有证据支持的扩大结论 | 不能推出 A 已经是最佳行动 |

实际阅读顺序：

1. 确认原生问题要回答什么，以及哪些内容是事实背景、假设条件或需要抵抗的错误证据。
2. 确认比较轴：官方原题/变体、题内假设、证据条件变化，还是知识编辑中的某个测试。缺少官方对应关系时，不自行拼接一条参照题。
3. 对比**全部相关上下文**，指出实际改变、保持的关键条件及被改变的对象。多人物题必须分清患者、母亲、婴儿、亲属等。
4. 把具体目标列出来，分别判断 R1–R5 是否有依据，写出不能推出的结论。
5. 最后记录子判断结论、父标签并集及评测资格；不要先看已有模型输出再倒推标签。

后面各节的条件用于作出实质判断，不是靠关键词命中自动分类。相同模板可以共读上下文，但每个单元都要满足本项变化和目标的具体条件。

#### 3. R1 新增支持：必须是真的新增，并且支持具体目标

**判定条件：**能找出改变后的支持条件 C、被支持的判断 J，以及 C 为什么支持 J；还要核对原题没有已经提供同一条件。增加一个句子不等于增加一条新依据，支持也不要求足以唯一确定答案。

**定义示例。** 某规则明确规定条件 C 是行动 A 的一个适用条件。变体中新出现 C，可给“A 的这一适用条件获得支持”标 R1；不能直接写“A 是最佳行动”。

**已审正例：新增呼气哮鸣。** `M01:case_10000:review_target_0`：原病例已有咳嗽、发热背景，变体新增呼气时哮鸣，原题未给出这一同类特征。既有审核保留对支气管炎候选的 R1：新增的是气道表现的支持，不能据此宣称确诊。见[已审判断](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/data/analysis_judgments.csv.gz)和[语义审核](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/classification/semantic_review.jsonl)。

**已纠正反例：夜间更重不等于较既往加重。** `M01:case_19017:review_target_1`：文字描述夜间咳嗽更明显、平卧时呼吸困难，不能把其中的 more 理解成“呼吸困难比患者平时更严重”。即使背景写有 COPD，也补不出这项时间比较；该目标的 R1 已撤下。其他真正有依据的子目标独立保留。见[修改明细](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/corrections/修改明细.csv)。

**已纠正反例：重复家族史不算新增。** `M12:77:black:review_target`：原题已经提到同两位亲属及其疾病，变体再次讲述，不是新增家族病例。原 R1/R3 已撤销；对于“给定表现下哪项检查能确认诊断”这一具体目标，修正为 R5。见[修改明细](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/corrections/修改明细.csv)。

延续的细则：

- “较既往加重”必须有明确的时间比较；“夜间更重”“平卧更重”是不同关系。旧审核保留了 24 个明确写有“比平时更严重”的判断，并非禁止所有症状加重类 R1。
- 新增购买某药的经济障碍、接受指定检查的条件，可能影响相应行动的可实施性；必须写明具体行动及方向。健康教育、泛泛求医意愿、希望快速康复，不能自动支持某个治疗方案。
- 亲属病史需要先确认病名及亲属与患者的关系，再判断其是否支持本题候选；不能将社区讨论的疾病名称绑定为亲属已确诊的疾病。

#### 4. R2 撤销支持：需要可核对的原依据及明确失效

**判定条件：**指出原先哪条条件支持哪个判断，变体怎样明确取消或反驳这条条件。原依据可以来自官方参照，也可以是原题清楚写出的题内前态/假设；不能从一个名称或没有配对的孤立否定句补造前态。

**定义示例。** 原来因为 C 禁止行动 A，变体明确取消 C，可对“因 C 而禁用 A”标 R2。若另一个风险 D 仍在，R2 仍可以成立；撤销的是 C 这一条依据，不是全部限制。

**已审正例：一条人口学支持被撤销。** `M14:GenderDataset.csv:row169:source852:review_target_0`：男孩改成女孩，自伤、发育迟缓和高尿酸等线索仍保留。原审核据该题的遗传模式依据，将“男性这一支持 Lesch–Nyhan 病因的流行病学依据被撤销”记为 R2。结论限于这一条支持：不能推出病因被完全排除，也不能要求最终选项必须改变。见[语义审核](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/classification/semantic_review.jsonl)与[已审判断](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/data/analysis_judgments.csv.gz)。

**已纠正反例：有否定句，但没有可核对的撤销关系。** `M02:SS-CF-DE-001-NEG:review_target_0`：本行只明确当前无谵妄/无谵妄史，既有材料未提供足以核实的具体前态或逐题规则映射，也不能据此认定相应高风险条件全部取消。仅凭作者的 risk deactivation 名称不够，该目标转为证据不足。若以后取得明确前态，可只对被取消的那条依据重新判 R2。见[修改明细](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/corrections/修改明细.csv)。

延续的细则：

- 删去“有症状 C”不等于加入“明确没有 C”。可以记录可见证据组合改变，但不能据此制造临床阴性。
- 其他风险仍在，并不是否决 R2 的理由；缺少原支持条件或明确取消证据才是本类的关键问题。
- 旧审核撤下的 6 个 MedPIC R2 针对上述证据缺口；另有 2 个明确排除高风险条件的判断被保留。不能把这次纠错推广成“MedPIC 的 R2 全无效”。

#### 5. R3 重新比较：至少两个候选及相对依据

**判定条件：**写出至少两个可识别候选 A、B，以及变化如何影响它们的相对支持。候选可以是诊断、处理方案或具体规则路径。仅写“需要重新考虑”“答案变化”不够；只支持一个目标而没有可说明的候选比较时，先考虑 R1。

**定义示例。** 原信息支持诊断 A，变体增加支持 B 的信息，并改变原有证据组合；在可识别的 A/B 间重新比较。若另有明确否定 A 的条件，才再判断 R2。

**已审正例：既往气胸史替换为 DVT 史。** `M01:case_13249:review_target_1`：原题给出自发性气胸个人史，变体替换为深静脉血栓个人史。既有审核明确写出自发性气胸与肺栓塞两个候选，以及两边风险依据的变化，保留 R3。未再出现气胸史，仍不能解读为患者明确没有气胸史。见[语义审核](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/classification/semantic_review.jsonl)与[已审判断](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/data/analysis_judgments.csv.gz)。

**已纠正反例：凭泛称亲属病史制造候选比较。** `M12:1:black:review_target`：亲属仅被描述为有肾脏/皮肤异常和罕见炎症性疾病，社区讨论的血管炎并没有被确认为这些亲属的诊断。相关家族风险联系未核实，因此不能添加对本人具体血管炎候选的 R1，也不能进一步添加与胆固醇栓塞比较的 R3。原 R1/R3 均转为证据不足。见[修改明细](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/corrections/修改明细.csv)。

R3 不要求最后答案一定改变，也不要求两个候选都有新增事实。它要求相对比较本身有可核查依据。若唯一比较依据后来被撤销，依赖它的 R3 也须一起重审。

#### 6. R4 推导后果：改变前提后，推断未给出的结果

**判定条件：**写出改变的前提 C、要推断的后续结果 Y，以及题目或一手来源支持的 C→Y 关系。Y 不能已经作为变体的新答案直接给出。题目可以是单题内的反事实假设，不要求额外制造 treated/untreated 或 factual/counterfactual 配对。

**定义示例。** 题面给出某处理会影响某指标，随后改变处理，询问指标或相关风险如何变化。需要用关系推出结果，而不是抄出编辑后的事实。

**已审正例：未用药时的检验结果。** `M05:question_41:review_target_0`：题目问，如果患者从未使用 fenofibrate，其 HDL 是否仍为原来的 77.6。原审核结合来源的药物—脂蛋白关系，保留 R4：替代情景的 HDL 没有直接给出。本例解释任务功能，不能由 R4 标签推导出一个精确反事实数值；该来源对新答案仍有原生人工评分要求。见[语义审核](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/classification/semantic_review.jsonl)。

**已审边界例：功能成立，参考仍不合格。** `M25:eval:554:portability_0`：从编辑后的鳞状细胞癌追问并发后果，后果没有直接作为编辑目标给出，保留收窄后的 R4；但原题对“common”的频率断言未核实，原参考禁止用于对应评分，且该来源有缺图限制。R4 成立不等于参考正确或任务已可运行。见[修改明细](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/corrections/修改明细.csv)。

延续的细则：

- “把疾病 X 改成疾病 Y，再问现在是什么病”以及重述编辑后知识，不自动算 R4。
- 名为 Complication、portability、causality 或 counterfactual 的字段，不替代实际的前提—结果关系。
- EquityMedQA 中已审的 Listeria 后果题，R4 来自题内“如果不治疗”的假设，不能把它误记为人口属性变化造成该后果。
- 有依据判定任务需要后果推断，不代表已经知道该患者真实的反事实结局。原参考可靠性单独记录。

#### 7. R5 保持判断：明确什么应保持，为什么应保持

**判定条件：**指出变化 C、应保持的具体目标 J，以及 C 与 J 无关的依据或原任务明确的保持约束；同时核对实际内容没有引入破坏该关系的变化。作者意图和相同 gold 可用于定位任务，不能替代这项核对。

**定义示例。** 只改变对当前问题无关的身份信息，相关诊断依据保持；或者更新一条医学知识，同时检查确实无关的另一条知识是否保持。不能把“更新知识后所有问题都该保持”当作 R5。

**已审正例：族群变化不改所问药理机制。** `M10:medqa_00001:variant_02:review_target_0`：原病例的膀胱癌化疗、耳毒性表现及听力检查保持，变体新增族群描述。原审核将 R5 绑定到“题目所指同一药物的作用机制”，没有把族群在所有医学问题中都视为无关。见[语义审核](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/classification/semantic_review.jsonl)。

**已纠正正例：把目标收窄到检查的诊断效力。** `M12:77:black:review_target`：临床表现、数值及同两位亲属病史保持；社区讨论、专科可及性不改变本题所问检查的诊断效力。因此原 R1/R3 改为这个目标上的 R5。不能把这一结论扩成“就医可及性对所有治疗问题都无影响”。见[修改明细](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/corrections/修改明细.csv)。

**已审边界例：目标应保持，但原 gold 有问题。** `M23:BioNLI:noise20:row4544:target_relation`：清洁/污染两端的当前 premise 与 hypothesis 相同，变化仅在外部检索演示。后续核对原研究后，保留对具体相容关系的 R5；原 negative 参考与核实依据冲突，保留原字段并禁止该参考评分，不把错误参考改写成新 gold。见[修改明细](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/corrections/修改明细.csv)。

延续的细则：

- 新增相关证据但最优答案碰巧不变，不凭这个事实标 R5；应先判断其支持、比较或后果作用。
- 性别、年龄、族群、地理位置及经济条件是否相关，要看具体问题。例如，所在地变化可能影响地方指南的适用，而非自动保持。
- CPV 中若给同一个人插入相反性别称谓却保留原性别/代词，要判断源构造是否自相矛盾；不能把构造错误当成合格 R5。多人物题则先确定变化指向谁。
- MedRGB/BioRAB 的原任务是抵抗错误证据，不能把噪声改造成必须接受的“新世界”。MedCounterFact 的假设证据遵循，须与现实医学合理性分开。
- MedCF/MedMKEB 的 locality 要核对是否真正无关或有明确保持约束。同题重述、相关关系及不可靠参考，不因字段名是 locality 就自动标 R5。

#### 8. 多标签、子目标和比较轴怎样保存

先对具体判断分类，再求父单元标签并集。一个子目标不能定类，不必删除其他已成立的判断；父标签存在，也不能证明所有子目标都完成了分类。

**已审的同题多标签例。** `M01:case_10000` 有两个具体判断：

| 判断 ID | 目标和依据 | 标签 |
|---|---|---|
| `M01:case_10000:review_target_0` | 新增呼气哮鸣，为支气管炎候选增加支持 | R1 |
| `M01:case_10000:review_target_1` | 原喉部声音变化线索与新增气道线索影响急性喉炎/支气管炎两个候选的比较 | R3 |

父语义标签为 R1/R3。删去喉部描述不构成明确阴性，所以不能顺手加 R2。这个语义结论与 v3 为展示而采用的互斥类别分配是两个字段层次。

**前三类共现的已审例。** `M16:CC_M_0028:CC_M_0027:SCREEN_JURISDICTION_REPLACEMENT`：所在地 Johannesburg 与 Manhattan 互换，问题明确询问当地宫颈癌筛查指南。既有审核分别识别新辖区规则的支持、旧辖区适用理由的撤销及两个规则路径的比较，记录 R1/R2/R3。撤销的是旧辖区作为首选规则的理由，并非宣称该地所有筛查都禁用。此例用于解释分类；EquityMedQA 的原生新答案评分资格另行处理。见[语义审核](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/audit_20260908/classification/semantic_review.jsonl)。

`comparison_axis` 在题内假设与外部配对容易混淆时必须说明。例如，一个人口属性对照中的题目又问“不治疗会怎样”，人口属性保持与题内后果推断是不同轴，不能把一个轴的标签转移到另一个轴。

MedRGB 的不同文档目标，MedCF/MedMKEB 的编辑、重述、locality 和其他测试，MedPerturb 的 VISIT、MANAGE、RESOURCE 都分别对应具体判断。只为 VISIT/MANAGE 建立了 R5，不能自动将 RESOURCE 也算成 R5。

**语义标签和展示标签分开。** 补分类时保留成立的全部语义标签。v3 的当前 `labels` 已经是互斥展示类别，不能把它当作原始语义标注覆盖回母库。查原分类用分析集的 `judgments`，或 v3 的 `classification_provenance.jsonl`。新版互斥展示只能在完整语义分类和资格确定后另行生成，不能为平衡类别删题或改语义。

#### 9. 哪些情况应暂不定类

沿用现有审阅结果名称，保持“已经判断”和“还没处理”的区别：

| 结果 | 何时使用 | 说明至少包含 |
|---|---|---|
| `classified` | 至少一个具体目标有足够依据 | 成立的标签、目标、依据及子目标覆盖情况 |
| `insufficient_evidence` | 已读相关材料，但缺少决定分类的必要前提/关系 | 已知什么、具体缺什么、影响哪个目标 |
| `invalid_source` | 原比较构造无效、自相矛盾或关键内容损坏 | 冲突/缺失字段及实际受影响范围 |
| `outside_five_labels` | 内容可读且已审，但不具备这五类所要求的功能关系 | 不满足的具体定义，不只写“不适用” |

未读、未跑完、中断或尚在等待来源材料的记录保留待处理状态；`outside_frozen_review_cohort` 是旧冻结名单之外的状态，不能翻译成语义不合格。原格式使用 `status=uncertain` 的记录可以保持该表达，但要有具体原因，不能用它掩盖未审。

对缺少依据的候选，先查原题和原生任务，必要时核对对应的一手关系依据。材料中确实缺少前态、目标或关系时可以暂不定类；处理太慢、第一次读不懂、分类器尚未写好，都不是最后的排除理由。也不能为了让某来源覆盖五类，补造医学因果关系或参考答案。

旧审核曾修正 172 个判断、涉及 130 个单元；其中 149 个判断转为证据不足。它们保留原记录，未随机抽别的题补数。后续复用修正结果，不退回 `pre_review_annotation` 或母库中的初标。

#### 10. 分类是否成立，与能否进入当前评测分开

分类描述变化对判断的功能；评测资格要求原任务能够在既定输入和评分条件下执行。满足其一不自动满足另一项。正式排除优先落到原生子任务或具体目标，不能因为一个目标需要人工评分就删除整个混合来源。

| 正式原因 | 按什么判断 | 本项目中的处理实例 |
|---|---|---|
| 新回答必须人工/rubric 评分 | 原任务没有可直接用于新答案的固定评分规则 | LabTest、EquityMedQA 的对应任务；保留已有分类，但不拿旧模型的人评分给新模型计分 |
| 必须多模态或关键图像缺失 | 明确定位题目所需但当前没有的图像/信号 | MedMKEB；文字题只是提到影像、或结果已完整转写，不自动排除 |
| 关键内容缺失 | 原题、选项、必要参照、配对或证据无法从固定原件无歧义恢复 | DiversityMedQA 先按准确原题恢复选项/gold；不能模糊拼题 |
| 原参考不可靠或评分依据缺失 | 具体 gold/映射问题及既有核对证据 | 沿用 11 个原参考的评分禁用标记；不把 11 个参考理解为 11 个整题 |
| 原协议不适用当前方法 | 原任务所必需的干预/编辑步骤确实未执行 | MedCF 原知识编辑评测不能用普通文本问答替代 |
| 分类关系不足或源构造无效 | 按前述具体定义及原文裁决 | 已审未定类保留理由；无实际变化的记录保留作参照 |
| 作者真实划分不属于评测范围 | 核实原 train/valid/test 的用途 | MedCF train/valid 不作为遗漏 test 补入；仅名为 train 的发布文件须先核实际含义 |

有已发布的人工 gold 不等于每次都需要人工评分。MedPerturb 已有 yes/no 目标和 gold，可按原生目标固定评分；RESOURCE 的分类仍单独判断。MedRGB 则分别核定主问题固定答案、错误文档 ID 和文档纠正内容：缺少位置依据或需要长答案人工语义评价的目标单列，其他可独立执行的合格原生目标保留。历史本地六档文档条件不能直接当成作者原始条件或官方位置映射。

分类依据不足与 gold 不可靠也要分开。例如第 6 节的 R4 仍可成立，但原参考禁用；第 7 节的 BioRAB R5 可以收窄后保留，却不能用错误参考评分。保留 `scoring_eligible`、`gold_review_status`、`scoring_exclusion_reason`；空值不是“已经独立核实合格”。

原本需要人工评价的任务，不能临时换成另一个模型打分后宣称满足固定规则评分范围。用模型辅助分类与用模型给待测方法的新答案打分，是两个不同环节。

#### 11. 后续补分类的范围和交付

保留 v3，另建后续版本。覆盖已取得的 15 个来源，所有符合分类和原生评测要求的内容全部纳入；不得再因“数量太多”“R5 太多”抽样或整批排除。原始版本、作者划分和必要参照继续保留。历史未取得的另外 11 个候选来源单列为获取缺口。

| 仅因抽样遗漏的来源 | 抽样前有效池 | 已审 | 待补候选 |
|---|---:|---:|---:|
| MedEinst | 5,300 | 2,500 | **2,800** |
| CPV-MedQA | 10,225 | 2,500 | **7,725** |
| DiversityMedQA | 6,296 | 2,500 | **3,796** |
| BioRAB | 12,615 | 2,500 | **10,115** |
| 合计 | 34,436 | 10,000 | **24,436** |

另有 **18,238 个已分类 R5 暂缓候选**，主要复用已有判断并恢复资格审查：Cultural 1,107、AMQA 4,164、DiversityMedQA 2,376、MedPerturb 3,615、MedRGB 3,680、BioRAB 2,499、MedCF 797。这不是尚未分类的新题数，也不是承诺全部可测。MedCounterFact 的 703 个 R1/R5 重叠单元已在 v3，恢复语义记录不算新增。

母库在旧冻结分析集外的 27,748 个记录，并非全是抽样遗漏：**27,748 = 24,436 + MedEinst 83 个无变化 + MedPerturb 14 个无变化 + MedCF 3,215 个 train/valid 实际编辑**。不得把这些差额都补进 test。详细历史见[流程说明](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-10_r1_r5_process_history/README.md)和[抽样清单](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-08_medical_cf_five_labels/reports/analysis_selection.json)。

接手执行时：

1. 从完整母库枚举 ID，连接已修正分析集，区分待补候选、已分类暂缓、已审未定类和已知正式排除。旧 `assemble_full.py` 包含抽样/初标逻辑，不直接重跑来覆盖现有标注。
2. 按本指南对合格遗漏项和必要未决子目标继续判断。原有 1,127 个有父标签的文本单元仍含未决子目标，拟纳入的那些目标也须补判。旧记录只有受新证据或已发现规则错误影响时才在新版修正。
3. 分批保存原 ID 和完成状态，中断后从剩余项恢复。最终交付逐目标分类与依据、覆盖清单、排除及未定类理由、新旧变化表、来源/类别统计及图表。未审完如实保留待处理，不改称排除。

完成意味着既定来源的记录去向清楚、24,436 个遗漏候选及 R5 暂缓范围均得到有依据的处置、拟纳入目标全部有分类和评测资格。最终可测数量由这些判断决定，不预先凑固定题数。比较单元、具体判断、原题根、独立输入和评分映射分别计数。

#### 12. 本地文件入口与读取顺序

先读本指南，再按当前问题读取下列材料；无需重新遍历所有历史对话。`/home/data3/txy/AGENTS.md` 与 `/home/data3/txy/MEDRGAG_WORKSPACE_GUIDE.md` 提供项目入口和当前结果位置。

来源母库目录：

```text
/home/data3/txy/Documents/Codex/2026-09-08/ben-c-h-ma-r-k/medical_cf_collection/
```

| 该目录下的文件 | 用途 |
|---|---|
| `分类与抽样说明.md` | 原五类定义；其中旧抽样规则只作历史，后续范围按本指南 |
| `全部比较单元.jsonl` | 完整母库及来源记录；未入选部分不等于已审 |
| `分析子集.jsonl` | 已审完整记录、原始题目和具体判断 |
| `分析子集_具体判断.csv` | 逐目标标签、理由、证据、未定类及评分状态 |
| `分析子集_逐题标注.csv` | 父单元标签、审阅方式和子目标覆盖情况 |
| `分析子集_未能定类.csv` | 已审无标签记录及理由 |
| `reports/分类审阅报告.md` | 已采用的分类边界及审阅口径 |
| `audit_20260908/classification/semantic_review.jsonl` | 初次具体实例审核；有后续修改时以修改后结果为准 |
| `audit_20260908/corrections/修改明细.csv` | 修改前后对象、标签、理由和参考处理；本指南反例的定位入口 |
| `audit_20260908/corrections/clinical.jsonl`、`amqa.jsonl`、`gold.jsonl` | 已落地的固定分类修正 |
| `reports/analysis_selection.json` | 原抽样名单规模和母库/已审集合口径 |
| `parts/` 与原始来源定位 | 必要时回看官方原件及完整上下文 |

v3 本地目录：

```text
/home/data3/txy/Documents/Codex/2026-08-23/https-github-com-xiotakut-cf-mrg/cf_medrgag_validation_pack/benchmark_r1_r5_text_auto_cpv_v3_exclusive_20260909/
```

查 v3 的当前成员和展示类别用其 `units.jsonl`；查原分类用 `classification_provenance.jsonl` 或上述已审分析集。旧预测只在分类确定后的评测阶段连接，不能作为标签依据。补分类写新目录，保留 v3 和历史原件。

#### 13. 这些示例能证明什么

本文复述已有分类定义及具体审核裁决，没有新增医学诊疗建议或重写原 gold。已有审核包含逐项语义审阅、分组审阅和结构核验，未经临床专家复核的记录继续保留 `clinical_review=false`。来源真实、分类关系有依据、原参考可靠、原任务可执行是分别记录的结论。

实例不是可以跨所有疾病或题型机械套用的模板。接手者应复用其中的判定关系和纠错边界，再核对新题的实际上下文。若新证据推翻旧裁决，在新版中记录具体修改及其影响，保留历史版本。


#### 论文写作与调整追溯（2026-09-13）

[工作与具体调整总记录](https://github.com/xiotakut/cf_mrg/blob/main/benchmarks/2026-09-13_r1_r5_paper_work_record/README.md)汇总本线程的版本形成、分类/资格修改、随机抽样、验证证据和Methods草稿；本地为 `/home/data3/txy/Documents/Codex/2026-09-09/agent-md-medrgag-workspace-guide-md/paper_work_record_20260913/README.md`。旧分类与抽样冻结记录保持不变，后续运行状态在总记录中单列。
