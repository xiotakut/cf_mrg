"""Serialize conversation-authored decisions; no label inference or model calls."""
import json,hashlib,datetime,importlib.util,collections
from pathlib import Path
OUT=Path(__file__).resolve().parent; PACK=OUT.parent/'audit_packet'
cs={r['blind_id']:r for r in map(json.loads,(PACK/'cases.jsonl').read_text().splitlines())}
spec=importlib.util.spec_from_file_location('audit_validator',PACK/'validate_audit.py'); mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
schema=json.loads((PACK/'output.schema.json').read_text())
def pointer(k):
 parts=k.split('/');parts[0]={'c':'current_input','r':'reference_input'}[parts[0]];parts[1]={'q':'question','e':'fixed_evidence','o':'options'}[parts[1]]
 return '/'+ '/'.join(parts)
def evidence(case,k,quote):
 path=pointer(k); val=case
 for part in path.split('/')[1:]:val=val[int(part)] if isinstance(val,list) else val[part]
 assert quote in val,(case['blind_id'],k,quote)
 start=val.index(quote)
 return dict(path=path,start=start,end=start+len(quote),quote=quote)
presets={
 'counterfactual_request':{'R4':'题内明示改变用药前提并要求判断尚未给出的反事实结局，确认R4任务需求；不确认临床因果关系或答案。'},
 'unchanged_target':{'R1':'待判前提与命题未变，其他演示例没有新增目标支持。','R2':'当前目标的前提没有被撤销或反驳；另一个演示的更换不构成目标支持撤销。','R3':'待判命题、目标及标签集合相同，演示变化不构成该目标候选相对依据变化。','R4':'当前目标是给定前提与命题的关系，不是改变该前提后推导新后果。','R5':'两侧待判前提与命题逐字相同；变化发生在其他演示，因此目标语义关系应保持。'},
 'preserved_reported_outcome':{'R1':'按研究内容对齐后，目标结局的报告依据保持，没有新增该结局支持。','R2':'对齐研究中的目标结局依据没有明确失效或被反驳。','R3':'给定研究的比较及所问结局报告保持，无须因名称替换重新判定相对结局。','R4':'结局已在给定研究中直接陈述，不是需要推导的未给干预结果。','R5':'对齐文献的目标结局数值/陈述保持，支持限定于给定文本的判断保持，不证明真实干预效力。'}}
defaults={'R1':'尚不能核实变化为指定目标新增何种有效支持。','R2':'尚不能核实原支持被明确撤销；未提及不等于否定。','R3':'尚不能核实变化如何影响两个候选的相对支持。','R4':'尚不能核实指定比较轴是否要求有依据的未给后果推导，不能把一般临床推理自动归类。','R5':'尚缺足够依据证明变化对指定目标无影响；答案相同或信息相似不是证明。'}
records=[];notes=[];batches=[];nquotes=0
for file in sorted((OUT/'batches').glob('batch_*.notes.jsonl')):
 batch=[]
 for line in file.read_text().splitlines():
  if not line.strip():continue
  n=json.loads(line);case=cs[n['id']];ev=[evidence(case,*q) for q in n['quotes']]
  assert len(n['v'])==5
  rs={};custom=presets.get(n.get('preset'),{})|n.get('rationale',{})
  for i,v in enumerate(n['v'],1):
   r=f'R{i}';verdict={'I':'insufficient','Y':'yes','N':'no'}[v]
   assert v=='I' or r in custom,(n['id'],r,'missing positive/negative reasoning')
   rs[r]=dict(verdict=verdict,evidence=ev,relation_rationale=n['observation']+' '+custom.get(r,defaults[r])+' '+n['limitation'],basis_level=n.get('insufficient_basis','needs_expertise') if v=='I' else 'explicit_input',external_sources=[],cannot_infer=n['limitation'],open_questions=[n['limitation']] if (v=='I' or 'clinical_consequence_unverified' in n['issues']) else [])
  row=dict(blind_id=n['id'],audit_identity='LLM-assisted evidence audit; not independent clinical validation',relations=rs)
  nquotes+=mod.validate(row,cs,schema);batch.append(row);notes.append(n)
 out=file.with_name(file.name.replace('.notes.','.results.'));out.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in batch))
 records+=batch;batches.append(dict(batch_id=file.name[:8],ids=[r['blind_id'] for r in batch],notes_sha256=hashlib.sha256(file.read_bytes()).hexdigest(),results_sha256=hashlib.sha256(out.read_bytes()).hexdigest()))
assert len({r['blind_id'] for r in records})==len(records)
(OUT/'audit_results.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records))
rr=json.loads((OUT/'run_record.json').read_text());rr.update(status='in_progress' if len(records)<120 else 'semantic_review_complete_pending_closeout',completed_semantic_audits=len(records),batches=batches,actual_api_requests=0,last_serialized_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(OUT/'run_record.json').write_text(json.dumps(rr,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(targets=len(records),literal_citation_instances=nquotes,results='schema and literal spans passed'),ensure_ascii=False))
