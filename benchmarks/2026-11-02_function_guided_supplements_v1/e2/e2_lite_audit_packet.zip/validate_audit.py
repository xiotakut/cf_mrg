"""Validate audit schema and literal quote spans only, never clinical meaning.

Usage: python validate_audit.py audit.jsonl [--require-complete]
Requires jsonschema. Partial submissions stay partial; no labels are filled in.
"""
import argparse,json
from pathlib import Path
import jsonschema

ROOT=Path(__file__).resolve().parent

def validate(record,cases,schema):
 jsonschema.validate(record,schema)
 case=cases[record['blind_id']]
 quotes=0
 for relation in record['relations'].values():
  if relation['basis_level']=='needs_expertise' and relation['verdict']!='insufficient':
   raise ValueError('Missing necessary expertise must remain insufficient')
  if relation['basis_level']=='referenced_external' and not relation['external_sources']:
   raise ValueError('External basis needs a traceable source; existence is not verified here')
  if relation['verdict'] in ('yes','no') and not relation['evidence']:
   raise ValueError('A yes/no decision requires located input evidence')
  for e in relation['evidence']:
   parts=e['path'].split('/')
   if parts[0]!='' or parts[1] not in ('current_input','reference_input'):
    raise ValueError('Quote must locate supplied original input')
   value=case
   for token in parts[1:]:
    token=token.replace('~1','/').replace('~0','~')
    value=value[int(token)] if isinstance(value,list) else value[token]
   if not isinstance(value,str) or not 0<=e['start']<e['end']<=len(value):
    raise ValueError('Invalid string span')
   if value[e['start']:e['end']]!=e['quote']:
    raise ValueError('Quote does not match literal source span')
   quotes+=1
 return quotes

def main():
 p=argparse.ArgumentParser();p.add_argument('results');p.add_argument('--require-complete',action='store_true');a=p.parse_args()
 cases={r['blind_id']:r for r in map(json.loads,(ROOT/'cases.jsonl').read_text().splitlines())}
 schema=json.loads((ROOT/'output.schema.json').read_text());seen=set();quotes=0
 for line in Path(a.results).read_text().splitlines():
  if not line.strip():continue
  record=json.loads(line);rid=record['blind_id']
  if rid in seen:raise ValueError('Duplicate audit target: '+rid)
  quotes+=validate(record,cases,schema);seen.add(rid)
 if a.require_complete and seen!=set(cases):raise ValueError('Complete audit must retain every target')
 print(json.dumps(dict(status='syntax_and_quote_locations_passed',submitted=len(seen),total_targets=len(cases),unsubmitted=len(cases)-len(seen),literal_quotes_checked=quotes,clinical_correctness_checked=False,functional_accuracy_estimated=False,external_sources_verified=False)))

if __name__=='__main__':main()
